# PHP Web Server

## Overview
A basic PHP web server setup for serving PHP files using PHP's built-in development server.

## Recent Changes
- 2025-11-16: Initial setup with PHP 8.4
- Created index.php with server info display
- Configured web server to run on port 5000

## Project Structure
- `index.php` - Main entry point displaying PHP server information
- Built-in PHP development server for serving files

## Running the Server
The PHP development server runs automatically via the configured workflow, serving files on port 5000.

## Dependencies
- PHP 8.4
- Built-in PHP development server
