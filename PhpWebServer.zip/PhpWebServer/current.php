<?php
if ($_SERVER["REQUEST_METHOD"] === "POST"){
// Safely get POST values (no warnings)
$reporter = isset ($_POST['reporter']) ? $_POST['reporter']: '';
$issue = isset ($_POST['issue']) ? $_POST['issue']: '';
$location = isset ($_POST['location']) ? $_POST['location']: '';
$description = isset ($_POST['description']) ? $_POST['description']:'';
}

else {
  echo "<h2> No Data Submitted. </h2>";
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Submitted Report</title>
</head>
<body>

  <h2>Report Submitted </h2>

  <p><strong>Reporter Name:</strong> <?php echo htmlspecialchars($reporter)?></p>
  <p><strong>Issue Type:</strong> <?php echo htmlspecialchars($issue) ?></p>
  <p><strong>Location:</strong> <?php echo htmlspecialchars($location) ?></p>
  <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars ($description)) ?></p>

  <br><br>
  <a href="index.php">Submit Another Report</a>

</body>
</html>